plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hykon.solardash"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hykon.solardash.neo"
        minSdk = 26
        targetSdk = 34
        versionCode = 19
        versionName = "2.8"
    }
    buildTypes {
        debug {
        }
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
