# Hykon Solar Neo (Android)

A refreshed visual design for the existing Hykon Solar dashboard. This separate Android app keeps the original installed app intact while retaining the existing dashboard functionality and native integrations.

## Preserved functionality

- Existing dashboard calculations, charts, tables, reports and settings.
- DessMonitor login, data fetch, live refresh and history.
- Native sign-in/key retrieval bridge and HTTP integration.
- Import/open/share support for XLSX, XLS, CSV and TXT files.
- Daily summary sharing, including image and text sharing.
- Saved dashboard data and existing preferences.
- Existing dashboard functionality and native integrations. This is a separate Android app installation.

## App identity

- Display name: **Hykon Solar Neo**
- Android application ID: `com.hykon.solardash.neo` (different from the original, so both apps can be installed together)
- Version: `2.8` (version code 19)
- APK artifact filename: `HykonSolar-Neo.apk`

## Build the APK with GitHub Actions

1. Upload the **contents of this project folder** to the root of your GitHub repository (so `app/` and `.github/` are at the repository root).
2. Open **Actions**.
3. Run **Build Hykon Solar Neo APK** (or push to `main`).
4. Open the completed workflow run and download the `HykonSolar-Neo-apk` artifact.
5. Extract `HykonSolar-Neo.apk` and install it on your Android phone.

The workflow builds a standard Android debug APK. It does not contain or expose the original app signing keystore. Because the application ID is different, it installs separately from the original app.

## Android Studio build

Open this folder in Android Studio, sync Gradle, then select **Build > Build APK(s)**. The generated debug APK is initially named `app-debug.apk`; rename it to `HykonSolar-Neo.apk` if desired.

## Design implementation

The refresh is implemented as CSS presentation overrides in `app/src/main/assets/index.html`. Existing HTML element IDs, JavaScript, data handling, calculations, and Android bridge code are retained.
