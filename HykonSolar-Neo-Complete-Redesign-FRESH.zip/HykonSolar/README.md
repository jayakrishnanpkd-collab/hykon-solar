# Hykon Solar Neo 3.0

A separate-install Android edition of the Hykon Solar monitoring dashboard. The original project is retained as the functional reference; the Neo interface adds a premium energy command centre and diagnostic insight layer while keeping the existing monitoring and data workflows.

## Neo experience
- Premium dark energy-console visual system with responsive mobile layouts, animated status accents and custom solar-energy graphics.
- Daily solar yield hero, specific yield (kWh/kWp), peak PV power, energy-mix donut, load, import/export and battery SOC summary.
- Performance intelligence cards for specific yield, grid-voltage excursions, battery SOC/throughput, outages, telemetry gaps and data provenance.
- Solar share is explicitly labelled indicative; inverter-derived import/export and battery energy remain estimates unless reconciled with actual meter readings.

## Existing capabilities retained
- DessMonitor authentication, inverter/device selection, historical fetch and live refresh.
- Inverter power-flow animation, voltage and SOC trends, signal charts, filters, parameter comparison and sample tables.
- Tuya smart energy meter integration, live meter values, switch controls and meter history.
- KSEB billing-cycle estimates, bill entry, meter reconciliation, savings and what-if calculations.
- Battery performance, monthly trends, round-trip estimates, backup/restore, WhatsApp sharing and CSV/XLSX/TXT imports.
- Android file sharing/open-with support and native HTTP bridge.

## Logic hardening
- CSV/TSV parsing now supports quoted fields, escaped quotes, commas inside quoted values and UTF-8 BOMs.
- CSV and XLSX imports detect the timestamp column even when it is not the first column.
- Neo diagnostics distinguish meter-backed values from inverter-derived estimates and flag telemetry gaps; they do not silently convert estimates into measured facts.

## Android identity
- Display name: Hykon Solar Neo
- Application ID: `com.hykon.solardash.neo`
- Version: 3.0 (version code 30)
- The original app ID remains unchanged, so both apps can be installed side-by-side.

## Build
Upload this ZIP to a new private GitHub repository, then add `.github/workflows/build-hykon-solar-neo.yml` using the workflow file supplied with this package. Run it from Actions and download the `HykonSolar-Neo-apk` artifact.

The APK produced by the workflow is a debug build for personal installation/testing. Validate cloud login, inverter data, Tuya meter readings and KSEB calculations against your actual equipment before relying on the results.
