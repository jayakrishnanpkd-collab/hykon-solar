# Hykon Solar Neo 3.0

A separate Android installation of the Hykon Solar dashboard. The original app remains untouched.

## Build identity
- Display name: Hykon Solar Neo
- Application ID: `com.hykon.solardash.neo`
- Version: `3.0` (versionCode 19)
- Original application ID remains `com.hykon.solardash`

## Preserved functionality
- DessMonitor sign-in/key discovery and native HTTP bridge
- Live inverter polling and header-aware API requests
- Smart energy meter/Tuya connection and controls
- Historical CSV/XLS/XLSX import, embedded sample data and daily navigation
- PV/load/battery/grid charts, comparison, filters and history
- KSEB meter readings, billing/savings calculations and estimates
- Battery analysis, inverter efficiency and health checks
- Share image/text/WhatsApp, Android file-open and file-share intents

## Changes in this build
- Complete dark, premium energy-console visual redesign with responsive layouts
- New app label and launcher icon
- Separate application ID so Neo can coexist with the original app
- CSV/XLSX parsing now handles quoted CSV cells, escaped quotes, multiline fields, BOM, comma/tab/semicolon delimiters, and timestamp columns that are not the first column
- Energy-balance diagnostics no longer silently cap impossible calculated efficiency above 100%; they flag the mismatch and withhold the efficiency result
- Kept the existing domain calculations and integration logic intact; no unsupported changes to electrical/energy assumptions were made

## Calculation caveats
- Import/export are model estimates unless actual smart-meter readings are entered or fetched. The UI already distinguishes actual and estimated values in key areas.
- Inverter efficiency and loss calculations are estimates without both actual import and export meter readings.
- Self-consumption and self-sufficiency depend on the chosen actual/estimated meter values and should not be treated as utility-billing measurements.
- Battery capacity calibration defaults to 5.12 kWh; set it to the actual usable capacity for meaningful cycle/energy calculations.
- This is a data-analysis dashboard, not a protection/control system. Do not use calculated estimates to change electrical protection settings.

## Build
The repository includes `.github/workflows/android.yml`. For ZIP-upload builds, upload this project ZIP to a new GitHub repository and add the companion workflow that extracts the ZIP before running Gradle.
