plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hykon.solardash"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hykon.solardash.neo"
        minSdk = 26
        targetSdk = 34
        versionCode = 19
        versionName = "3.0"
    }
    signingConfigs {
        create("hykon") {
            storeFile = file("hykon.keystore")
            storePassword = "hykonsolar"
            keyAlias = "hykon"
            keyPassword = "hykonsolar"
        }
    }
    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("hykon")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("hykon")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
