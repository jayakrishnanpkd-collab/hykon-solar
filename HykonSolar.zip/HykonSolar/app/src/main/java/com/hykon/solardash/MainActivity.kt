package com.hykon.solardash

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var pageReady = false
    private var pending: Pair<String, String>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                pending?.let { push(it.first, it.second); pending = null }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = callback
                val pick = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                @Suppress("DEPRECATION")
                startActivityForResult(Intent.createChooser(pick, "Select log files"), REQ_FILES)
                return true
            }
        }

        web.loadUrl("file:///android_asset/index.html")
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_FILES) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooser = null
        } else if (requestCode == REQ_KEY) {
            if (resultCode == RESULT_OK && data != null) {
                val base = JSONObject.quote(data.getStringExtra("base") ?: "")
                val key = JSONObject.quote(data.getStringExtra("key") ?: "")
                val usr = JSONObject.quote(data.getStringExtra("usr") ?: "")
                val rest = JSONObject.quote(data.getStringExtra("rest") ?: "")
                val sign = JSONObject.quote(data.getStringExtra("sign") ?: "")
                val salt = JSONObject.quote(data.getStringExtra("salt") ?: "")
                js("window.__keyFound($base,$key,$usr,$rest,$sign,$salt)")
            } else {
                js("window.__keyCancel && window.__keyCancel()")
            }
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    // Files opened with, or shared to, the app
    private fun handleIntent(i: Intent?) {
        val uri: Uri? = when (i?.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }
        if (uri == null) return
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@Thread
                val name = uri.lastPathSegment ?: "file"
                val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                runOnUiThread { if (pageReady) push(name, b64) else pending = name to b64 }
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun push(name: String, b64: String) {
        web.evaluateJavascript("window.__openFile(${JSONObject.quote(name)},${JSONObject.quote(b64)})", null)
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    // Native HTTP for the live feed, so browser cross-origin rules do not apply
    inner class Bridge {
        @JavascriptInterface
        fun findKey(url: String) {
            runOnUiThread {
                @Suppress("DEPRECATION")
                startActivityForResult(
                    Intent(this@MainActivity, LoginActivity::class.java).putExtra("url", url),
                    REQ_KEY
                )
            }
        }

        @JavascriptInterface
        fun shareImage(b64: String, name: String, text: String) {
            Thread {
                try {
                    val dir = File(cacheDir, "share").apply { mkdirs() }
                    dir.listFiles()?.forEach { it.delete() }
                    val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val f = File(dir, safe)
                    f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                    val uri = Uri.parse("content://$packageName.shareprovider/$safe")
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_TEXT, text)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    runOnUiThread { startActivity(Intent.createChooser(send, "Share daily summary")) }
                } catch (_: Exception) {
                }
            }.start()
        }

        @JavascriptInterface
        fun shareText(text: String, whatsapp: Boolean) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                if (whatsapp) {
                    try {
                        startActivity(Intent(send).setPackage("com.whatsapp"))
                        return@runOnUiThread
                    } catch (_: Exception) {
                    }
                }
                startActivity(Intent.createChooser(send, "Share"))
            }
        }

        @JavascriptInterface
        fun fetch(id: String, url: String) {
            Thread {
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000
                    c.readTimeout = 60000
                    c.instanceFollowRedirects = true
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) HykonSolar/1.0")
                    val code = c.responseCode
                    val stream = if (code >= 400) c.errorStream else c.inputStream
                    val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    js("window.__nativeDone(${JSONObject.quote(id)},$code,${JSONObject.quote(b64)},null)")
                } catch (e: Exception) {
                    val msg = e.message ?: e.javaClass.simpleName
                    js("window.__nativeDone(${JSONObject.quote(id)},0,'',${JSONObject.quote(msg)})")
                }
            }.start()
        }
    }

    companion object {
        private const val REQ_FILES = 1
        private const val REQ_KEY = 2
    }
}
